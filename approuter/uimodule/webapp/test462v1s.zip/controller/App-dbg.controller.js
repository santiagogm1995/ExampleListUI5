sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"test462v1s/test462v1s/controller/BaseController",
	"../utils/Utils"
], function (Controller, BaseController, Utils) {
	"use strict";
	

	return Controller.extend("test462v1s.test462v1s.controller.App", {
		onInit: function(){}
	});
});