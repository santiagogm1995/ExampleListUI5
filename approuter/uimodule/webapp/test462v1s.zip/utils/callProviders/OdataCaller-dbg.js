sap.ui.define([], function() {
  "use strict";
  return {
    GET: () => {
    },
    POST: () => {
    },
    DELETE: () => {
    },
    PUT: () => {
    },
    GETALL: () => {
    }
  };
});
